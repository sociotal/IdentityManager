package es.um.security.idm.user.test;

import java.util.ArrayList;

import javax.net.ssl.TrustManager;

import es.um.security.idm.tokens.Token;
import es.um.security.idm.user.IdMUser;
import es.um.security.idm.user.implementation.KeyRockIdMUserClient;
import es.um.security.utilities.CertificateUtil;
import es.um.security.utilities.Protocols;

public class TestKeyRockIdMUserClient {

	public static void main(String[] args) {
		
		try { 
//	    	IdMUser identityManager = new KeyRockIdMUserClient();
			
			/* Add trusted CAs' certificates */
			ArrayList<java.security.cert.X509Certificate> cas_certificates = new ArrayList<java.security.cert.X509Certificate>(); //Trusted CAs' certificates
			java.security.cert.X509Certificate ca_cert = CertificateUtil.getCertificate("CA_CERTIFICATE_PATH"); //Obtain X509 certificate from the CA certificate path, for example "certs/ca.cer"
			if(ca_cert != null) cas_certificates.add(ca_cert);//Add the CA certificate in the set of the CAs' certificates
			
	    	IdMUser identityManager = new KeyRockIdMUserClient(Protocols.HTTPS, cas_certificates);
//	    	IdMUser identityManager = new KeyRockIdMUserClient(Protocols.PROTOCOL, ArrayList<X509Certificate>, "KEYROCK_IP");
//	    	IdMUser identityManager = new KeyRockIdMUserClient(Protocols.PROTOCOL, ArrayList<X509Certificate>, "KEYROCK_IP", "KEYROCK_PORT");
	    	
    	   		    	        	
//    		/* ##### USER AUTHENTICATION BY ID AND PASSWORD ##### */	
//    		System.out.println("##### USER AUTHENTICATION BY ID AND PASSWORD #####");
//    		Token token_by_id = identityManager.authenticateById("ENTITY_ID", "ENTITY_PASSWORD");
//    		if(token_by_id != null)
//    			System.out.println("\tTOKEN: " + token_by_id.getToken_id());
    		    		
		} catch (Exception e) {
			e.printStackTrace();
		}    	
    }
	
}
