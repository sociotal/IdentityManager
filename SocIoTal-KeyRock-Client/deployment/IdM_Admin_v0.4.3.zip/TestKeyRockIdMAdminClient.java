package es.um.security.idm.admin.test;

import java.util.ArrayList;

import javax.net.ssl.TrustManager;

import es.um.security.idm.admin.IdMAdmin;
import es.um.security.idm.admin.implementation.KeyRockIdMAdminClient;
import es.um.security.idm.entities.*;
import es.um.security.idm.entities.attributes.*;
import es.um.security.idm.tokens.Token;
import es.um.security.utilities.CertificateUtil;
import es.um.security.utilities.Protocols;

public class TestKeyRockIdMAdminClient {

	public static void main(String[] args) {
		
		try {
//			IdMAdmin identityManager = new KeyRockIdMAdminClient("ADMIN_TOKEN"); 
			
			/* Add trusted CAs' certificates */
			ArrayList<java.security.cert.X509Certificate> cas_certificates = new ArrayList<java.security.cert.X509Certificate>(); //Trusted CAs' certificates
			java.security.cert.X509Certificate ca_cert = CertificateUtil.getCertificate("CA_CERTIFICATE_PATH"); //Obtain X509 certificate from the CA certificate path, for example "certs/ca.cer"
			if(ca_cert != null) cas_certificates.add(ca_cert);//Add the CA certificate in the set of the CAs' certificates
			
			IdMAdmin identityManager = new KeyRockIdMAdminClient("ADMIN_TOKEN", Protocols.HTTPS, cas_certificates); //To change
//	    	IdMAdmin identityManager = new KeyRockIdMAdminClient("ADMIN_TOKEN", Protocols.PROTOCOL, ArrayList<X509Certificate>, "KEYROCK_IP");
//			IdMAdmin identityManager = new KeyRockIdMAdminClient("ADMIN_TOKEN", Protocols.PROTOCOL, ArrayList<X509Certificate>, "KEYROCK_IP", "KEYROCK_PORT");
    	
			/* ATTRIBUTES */
        	Id id = new Id(CertificateUtil.obtainId("X509CERTIFICATE_PATH"));//To change. For example "certs/client.cer"
//        	Id id = new Id(CertificateUtil.obtainId(X509CERTIFICATE));
        	Domain domain = new Domain();
        	UserName user_name = new UserName("clientOne");
        	Entity entity = new User(id, domain, user_name);
        	
        	NickName att_nickName = new NickName("Client one");
        	Attribute<NickName> nickName = new Attribute<NickName>("nickName", att_nickName);
    		entity.setAttribute(nickName);
    		
    		Name att_name = new Name("Client one for test");
        	Attribute<Name> name = new Attribute<Name>("name", att_name);
    		entity.setAttribute(name);
    		
    		Address address = new Address("work", "University of Murcia", "Murcia", "30100", "Spain");
    		ArrayList<Address> arrayAddresses = new ArrayList<Address>();
    		arrayAddresses.add(address);    		
    		Attribute<ArrayList<Address>> addresses = new Attribute<ArrayList<Address>>("addresses", arrayAddresses);
    		entity.setAttribute(addresses);
    		
    		Email email = new Email("email_client@um.es");
    		ArrayList<Email> arrayEmails = new ArrayList<Email>();
    		arrayEmails.add(email);
    		Attribute<ArrayList<Email>> emails = new Attribute<ArrayList<Email>>("emails", arrayEmails);
    		entity.setAttribute(emails);
    		
    		Organization att_organization = new Organization("Client one organization");
        	Attribute<Organization> organization = new Attribute<Organization>("organization", att_organization);
    		entity.setAttribute(organization);
    		
    		Department att_department = new Department("Client one department");
        	Attribute<Department> department = new Attribute<Department>("department", att_department);
    		entity.setAttribute(department);
    		
    		es.um.security.idm.entities.attributes.X509Certificate cert = new es.um.security.idm.entities.attributes.X509Certificate(CertificateUtil.obtainCert("X509CERTIFICATE_PATH")); //To change. For example "certs/client.cer"
//    		es.um.security.idm.entities.attributes.X509Certificate cert = new es.um.security.idm.entities.attributes.X509Certificate(CertificateUtil.obtainCert(X509CERTIFICATE));
    		ArrayList<es.um.security.idm.entities.attributes.X509Certificate> arrayCertificates = new ArrayList<es.um.security.idm.entities.attributes.X509Certificate>();
    		arrayCertificates.add(cert);
    		Attribute<ArrayList<es.um.security.idm.entities.attributes.X509Certificate>> certs = new Attribute<ArrayList<es.um.security.idm.entities.attributes.X509Certificate>>("x509Certificates", arrayCertificates);
    		entity.setAttribute(certs);
    		
    		Password password = new Password("passw0rdCl1ent");
    		Attribute<Password> att_password = new Attribute<Password>("password", password);
    		entity.setAttribute(att_password);
    		
    		Active active = new Active(true);
    		Attribute<Active> att_active = new Attribute<Active>("active", active);
    		entity.setAttribute(att_active);
    		    	        	
//        	/* ##### ADD ENTITY (e.g. User) ##### */	
//    		System.out.println("##### ADD ENTITY (e.g. User) #####");
//    		identityManager.addEntity(entity);
//    		
//    		/* ##### REMOVE ENTITY (e.g. User) ##### */
//    		System.out.println("##### REMOVE ENTITY (e.g. User) #####");
//    		identityManager.removeEntity(entity);
//    		
//    		/* ##### REMOVE ENTITY BY ID (e.g. User) ##### */
//    		System.out.println("##### REMOVE ENTITY BY ID (e.g. User) #####");
//    		identityManager.removeEntity(((Id)entity.getId().getValue()).getValue());
//    		
//    		/* ##### MODIFY ENTITY (e.g. User) ##### */	
//    		System.out.println("##### MODIFY ENTITY (e.g. User) #####");
//    		entity.removeAttribute(emails);
//    		ArrayList<Email> newArrayEmails = new ArrayList<Email>();
//    		Email newEmail = new Email("new_email_client@um.es");
//    		newArrayEmails.add(newEmail);
//    		Attribute<ArrayList<Email>> newEmails = new Attribute<ArrayList<Email>>("emails", newArrayEmails);
//    		entity.setAttribute(newEmails);
//    		identityManager.updateEntity(entity);
//    		
//    		/* ##### GET ENTITY BY ID (e.g. User) ##### */	
//    		System.out.println("##### GET ENTITY BY ID (e.g. User) #####");
//    		Entity ent_by_id = identityManager.getEntityById(((Id)entity.getId().getValue()).getValue());
//    		if(ent_by_id != null && ent_by_id instanceof User)
//				System.out.println(ent_by_id);
//    			
//    		/* ##### GET ENTITY BY NAME (e.g. User) ##### */	
//    		System.out.println("##### GET ENTITY BY NAME (e.g. User) #####");
//    		Entity ent_by_name = identityManager.getEntityByName(((UserName)((User)entity).getUserName().getValue()).getValue());
//    		if(ent_by_name != null && ent_by_name instanceof User)
//				System.out.println(ent_by_name);
//    		    		
//    		/* ##### USER AUTHENTICATION BY ID AND PASSWORD ##### */	
//    		System.out.println("##### USER AUTHENTICATION BY ID AND PASSWORD #####");
//    		Token token_by_id = identityManager.authenticateById("ENTITY_ID", "ENTITY_PASSWORD");
//    		if(token_by_id != null)
//    			System.out.println("\tTOKEN: " + token_by_id.getToken_id());
//    		
//    		/* ##### USER AUTHENTICATION BY NAME AND PASSWORD ##### */	
//    		System.out.println("##### USER AUTHENTICATION BY NAME AND PASSWORD #####");
//    		Token token_by_name = identityManager.authenticateByName("ENTITY_NAME", "ENTITY_PASSWORD");
//    		if(token_by_name != null)
//    			System.out.println("\tTOKEN: " + token_by_name.getToken_id());
//    		    		
//    		/* ##### GET INFO TOKEN ##### */	
//    		System.out.println("##### GET INFO TOKEN #####");
//    		Token token = identityManager.getInfoToken("TOKEN_ID");
//    		if(token != null)
//    			System.out.println("\tToken_ID: " + token.getToken_id() + "\n\tUser_ID: " + token.getUser_id() + "\n\tUser_domain: " + token.getUser_domain() + "\n\tExpiry date: " + token.getExpiry_date());
    		
		} catch (Exception e) {
			e.printStackTrace();
		}    	
	}
	
}
